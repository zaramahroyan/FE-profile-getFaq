//import { NotificationContainer } from "react-notifications";
import Auth from "./components/auth";
import Userpage from "./components/userpage";
//import { useEffect, useState } from "react";
import { useSelector } from "react-redux";


function App() {
  const { loggedIn } = useSelector((state) => state.user);

  return (
    <div className="App">
      {loggedIn ? <Userpage /> : <Auth />}
    </div>
  );
}

export default App;
