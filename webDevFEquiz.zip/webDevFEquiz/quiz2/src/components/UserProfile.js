import { Box, Grid } from "@mui/material";
import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import axios from "axios";
import { setProfiles } from "../redux/app.reducer";


const userpage = () => {
  const token = useSelector((state) => state.user.token);
  const dispatch = useDispatch();

  useEffect(() => {
    getData();
  }, []);

  const getData = async () => {
    const response = await axios({
      method: "GET",
      url: "https://sandbox.practical.me/api/user/profile",
      headers: { Authorization: "Bearer ${token}" },
    });
    dispatch(setProfiles(response.data.wallet));}

  const profile = useSelector((state) => state.app.profile);
  return (
    <Box
      sx={{
        display: "flex",
        width: "100vw",
        height: "100vh",
        margin: "100px",
      }}
    >
      
      
    </Box>
  );
};

export default userpage;