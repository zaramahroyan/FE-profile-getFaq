import React from 'react'
import profile from "./profile";
import { Box, Grid } from "@mui/material";
import BasicTable from './profile';

function userpage() {
  return (
    <Box>
        <BasicTable />
    </Box>
  )
}

export default userpage;